import json
import os
import random
pose=['wonderful','you are a bookworm','are you smart','very good']
books={}
def save():
    global books
    with open('libdata.txt','w', encoding='utf-8') as myf:
        json.dump(books, myf, ensure_ascii=False, indent=4)
try:
       with open('libdata.txt','r', encoding='utf-8') as myf:
           books = json.load(myf)
except:
   books = {}
save()
def shaw():
    if os.name=='nt':
        os.system('cls')
    else:
        os.system('clear')
bo=[]        
for i in books :
    bo.append(i)



print('welcome to library app by omar hatim\n')
while True:
    print('1-add book📔')
    print('2-change pages📄')
    print('3-view👁️')
    print('4-exit and save📁')
    print('5-remove book❌')

    choose = int(input('\nenter one number(1-5):'))
    shaw()

    if choose == 1:
        z = input('enter title:')
        x = int(input('enter number of pages:'))
        v = int(input('enter number you read:'))
        books[z] = {'pages': x, 'readed': v}
        input('\nsuccess😎')
        shaw()
        save()

    elif choose == 2:
        print('books:\n','\n'.join(bo))
        c = input('enter book name:')
        if c in books:
            kl = int(input('new number of pages:'))
            books[c]['pages'] = kl
            kl1 = int(input('new number of pages did you read:'))
            if kl1>20:
                print(random.choice(pose))
            books[c]['readed'] = kl1
            save()
            input('succeeded😎')
            shaw()
            
        else:
            input('somthing wrong ,again')
            shaw()
    elif choose == 3:
        print('title::pages:readed')
        for title,info in books.items():
            print(f"{title}::{info['pages']}::{info['readed']}\n")
        input('finish?')
        shaw()
        save()
    elif choose == 4:
        with open('libdata.txt','w') as myf:
            json.dump(books, myf)
        print('saved,bye👋')
        break
    elif choose ==5:
        save()
        an=input(' , '.join(bo)+'\n')
        if an in books:
            books.pop(an)
            save()
            input('succeeded😎')
            shaw()
        else:
            input('invald❌')
            shaw()