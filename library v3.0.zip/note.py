import os
import shutil
class Note:
    def addbf(self,bookn):
        if not os.path.exists('notes/'+bookn):
            os.makedirs(os.path.join('notes',bookn),exist_ok=True)
        
    def fsure(self):
        if not os.path.exists('notes'):
            os.makedirs('notes')
     
    def addn(self,bookn,note):
       n=0
       while os.path.exists('notes/'+bookn+'/note'+str(n)+'.txt'):
           n+=1
           
       with open('notes/'+bookn+'/note'+str(n)+'.txt','w',encoding='utf-8') as f:
           f.write(note)  
    def rebo(self,bookn):
        shutil.rmtree("notes/"+bookn)
    def noten(self, bookn):
        kilo = []
        for note in os.listdir('notes/' + bookn):
            name, ext = os.path.splitext(note)
            import re
            match = re.search(r'\d+', name)
            if match:
                 i = int(match.group())      
                 with open(f'notes/{bookn}/note{i}.txt', 'r', encoding='utf-8') as op:
                     con = f"{i}-{op.read()}"
                     kilo.append(con)
        return kilo
    def remn(self,bookn,num):
        os.remove('notes/'+bookn+'/note'+num+'.txt')                        