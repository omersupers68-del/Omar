import sys
sys.stdout.reconfigure(encoding='utf-8')
import json
import os
import random
pose=['wonderful','you are a bookworm','are you smart','very good']
books={}
def save():
    global books
    with open('libdata.txt','w', encoding='utf-8') as myf:
        json.dump(books, myf, ensure_ascii=False, indent=4)
try:
       with open('libdata.txt','r', encoding='utf-8') as myf:
           books = json.load(myf)
except:
   books = {}
save()
def shaw():
    if os.name=='nt':
        os.system('cls')
    else:
        os.system('clear')
print('welcome to library app by omar hatim\n')
while True:
    print('1-add book📔')
    print('2-change pages📄')
    print('3-view👁️')
    print('4-exit and save📁')
    print('5-remove book❌')
    print('6-remove data🚫')

    choose = int(input('\nenter one number(1-5):'))
    shaw()

    if choose == 1:
        z = input('enter title:')
        x = int(input('enter number of pages:'))
        v = int(input('enter number you read:'))
        books[z] = {'pages': x, 'readed': v}
        input('\nsuccess😎')
        shaw()
        save()

    elif choose == 2:
        print('books:\n', '\n '.join(books.keys()))
        c = input('enter book name:')
        if c in books:
            kl = int(input('new number of pages:'))
            books[c]['pages'] = kl
            kl1 = int(input('new number of pages did you read:'))
            bj=books[c]['readed']-kl1
            if bj>=20:
                print(random.choice(pose))
            books[c]['readed'] = kl1
            if kl1>kl:
                print("hah? ,that's Impossible")
            elif kl1==kl:
                print('cogrations, you finsh the book🤩')
            save()
            input('succeeded😎')
            shaw()
            
        else:
            input('somthing wrong ,try again')
            shaw()
    elif choose == 3:
        print('title\npages:readed')
        for title,info in books.items():
            print(f"{title}\n{info['pages']}:{info['readed']}\n")
        input('finish?')
        shaw()
        save()
    elif choose == 4:                
       with open('libdata.txt','w', encoding='utf-8') as myf:
                    json.dump(books, myf, ensure_ascii=False, indent=4)
       print('saved,bye👋')
       break
    elif choose ==5:
        save()
        print('books:' + '\n '.join(books.keys())+'\n')
        an=input('enter the full book name:')
        if an in books:
            books.pop(an)
            save()
            input('succeeded😎')
            shaw()
        else:
            input('invald❌')
            shaw()
    elif choose ==6:
        USure=input('Are you sure?(that will delete all data you have)(y,n)')
        if USure=='y':
            books={}
            save()
            input('\nsucceeded😎')
            shaw()
        elif USure=='n':
            input('okay😎')
            shaw()                                   
        else:
            input('invald❌')  
            shaw()                                 